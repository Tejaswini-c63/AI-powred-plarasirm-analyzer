import nltk
#nltk.download('stopwords')
#nltk.download('punkt')
nltk.download('wordnet')

nltk.download('pros_cons')
nltk.download('reuters')
